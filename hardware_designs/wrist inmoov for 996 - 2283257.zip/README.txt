wrist inmoov for 996 by ambroise on Thingiverse: https://www.thingiverse.com/thing:2283257

Summary:
remix gear inmoov wrist for servo 996
