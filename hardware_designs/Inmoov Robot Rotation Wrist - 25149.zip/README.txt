Inmoov Robot Rotation Wrist by Gael_Langevin on Thingiverse: https://www.thingiverse.com/thing:25149

Summary:
IMPORTANT: If you want the latest updates visit my site:http://www.inmoov.frThis part is a rotational wrist for the hand robot "InMoov",For more parts and info, see thingiverse.com/thing:17773Assembly instructions, seehttp://www.inmoov.fryoutube.com/watch?v=BAs2F4sFVdAyoutube.com/watch?v=tXYF6yY1c9MVideo of rotation wrist:youtube.com/watch?v=lkmXFKQgZm8
