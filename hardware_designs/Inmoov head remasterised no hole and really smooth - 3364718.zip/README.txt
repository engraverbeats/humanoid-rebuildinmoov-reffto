Inmoov head remasterised no hole and really smooth by lepterois on Thingiverse: https://www.thingiverse.com/thing:3364718

Summary:
Inmoov head remasterised to be really smooth without faces
