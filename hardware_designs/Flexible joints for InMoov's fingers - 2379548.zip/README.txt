Flexible joints for InMoov's fingers by bhouston on Thingiverse: https://www.thingiverse.com/thing:2379548

Summary:
These are fingers for the InMoov hand with flexible joints. This is definitely a project in progress. Nothing fancy but they work great, they close and grip objects very well.Download and print all of the files.Download and print all of the original finger tips or reuse the the finger tips if you've already printed them.Print 14 Hinges out of flexible filament. Any flexible filament works. I printed mine with 2 shells and 75% infill.Cut the finger hinges off the original hand and glue/attach the Finger- Adapters in their place.String the fingers as in the original design.Attach the finger tips.Have fun!!!https://youtu.be/i7QKrtV81Mo
